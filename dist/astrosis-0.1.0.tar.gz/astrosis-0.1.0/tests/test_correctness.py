"""
tests/test_correctness.py — Astrosis Physics Correctness Tests
===============================================================
Replaced test_performance.py which only checked speed and had trivially-
passing assertions like `distance < 1.0` (true even for a broken detector).

Every test here either:
  (a) verifies a specific physics invariant with a tight numerical tolerance, or
  (b) would have caught a real bug from the pre-alpha codebase.

Run:
    pytest tests/test_correctness.py -v
"""

import math
import subprocess
import sys
import types
import pytest
import numpy as np

from astrosis.core.propagator import rk4_step
from astrosis.constants import (
    MU,
    RE,
    J2,
    CRITICAL_DISTANCE,
    WARNING_DISTANCE,
    ADVISORY_DISTANCE,
)
from astrosis.core.accelerator import (
    propagate,
    propagate_batch,
    detect_conjunctions,
    backend_info,
)

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _orbital_energy(state):
    r = math.sqrt(sum(x * x for x in state[:3]))
    v = math.sqrt(sum(x * x for x in state[3:]))
    return 0.5 * v * v - MU / r


def _circular_orbit(altitude_km=400.0, inclination_deg=0.0):
    """Return a circular-orbit state at a given altitude [km]."""
    r = RE + altitude_km
    v = math.sqrt(MU / r)
    inc = math.radians(inclination_deg)
    return [r, 0.0, 0.0, 0.0, v * math.cos(inc), v * math.sin(inc)]


# ─────────────────────────────────────────────────────────────────────────────
# 1. Energy Conservation
# ─────────────────────────────────────────────────────────────────────────────


def test_energy_conservation_one_orbit():
    """
    Specific orbital energy must be conserved to 1e-7 relative over one full orbit.
    This catches first-order integration mistakes and wrong gravity sign/magnitude.
    """
    state = tuple(_circular_orbit(400.0))
    T_orbit = 2 * math.pi * math.sqrt((RE + 400.0) ** 3 / MU)
    dt = 10.0
    n_steps = int(T_orbit / dt)

    eps0 = _orbital_energy(state)
    curr = state
    for _ in range(n_steps):
        curr = rk4_step(curr, dt)

    eps_final = _orbital_energy(curr)
    rel_err = abs((eps_final - eps0) / eps0)
    assert rel_err < 1e-7, (
        f"Energy drift {rel_err:.2e} after 1 orbit exceeds 1e-7. "
        f"Check gravity acceleration formula."
    )


def test_energy_conservation_24h():
    """
    Energy drift must stay below 1e-5 over a full 24-hour propagation (dt=30s).
    RK4 global error is O(dt^4); at dt=30s the 24-hour accumulated drift is
    ~7e-6, well within the operational requirement of < 1e-5 (10x tighter than
    the TLE uncertainty budget of ~1e-4 relative).
    """
    state = tuple(_circular_orbit(500.0))
    dt = 30.0
    n_steps = int(24 * 3600 / dt)
    eps0 = _orbital_energy(state)
    curr = state
    max_err = 0.0
    for i in range(n_steps):
        curr = rk4_step(curr, dt)
        if i % 120 == 0:  # sample every hour
            max_err = max(max_err, abs((_orbital_energy(curr) - eps0) / eps0))
    assert max_err < 1e-5, f"24h energy drift {max_err:.2e} exceeds 1e-5 (dt=30s)"


# ─────────────────────────────────────────────────────────────────────────────
# 2. RK4 Convergence Order
# ─────────────────────────────────────────────────────────────────────────────


def test_rk4_fourth_order_convergence():
    """
    Halving the step size must reduce global error by ≥ 14× (expect 16× for RK4).
    Proves the implementation is genuinely 4th order, not accidentally lower.
    """
    state = tuple(_circular_orbit(400.0))
    total_time = 7200.0

    def propagate_n_steps(dt):
        n = int(total_time / dt)
        curr = state
        for _ in range(n):
            curr = rk4_step(curr, dt)
        return curr

    # Reference: very fine integration over the same elapsed time.
    ref = propagate_n_steps(2.0)

    err_coarse = math.sqrt(
        sum((propagate_n_steps(60.0)[k] - ref[k]) ** 2 for k in range(3))
    )
    err_fine = math.sqrt(
        sum((propagate_n_steps(30.0)[k] - ref[k]) ** 2 for k in range(3))
    )

    ratio = err_coarse / max(err_fine, 1e-15)
    assert ratio >= 14.0, (
        f"RK4 error ratio = {ratio:.1f} (halving dt 60→30s). "
        f"Expected ≥ 14× (ideal 16×). Integration may not be 4th order."
    )


# ─────────────────────────────────────────────────────────────────────────────
# 3. Conjunction Detection — correctness (not just performance)
# ─────────────────────────────────────────────────────────────────────────────


def test_conjunction_detects_critical():
    """
    Two objects 0.05 km apart at t=0 must produce a CRITICAL warning.
    current_distance must be < CRITICAL_DISTANCE, not just 'less than 1.0'.
    """
    sat = [-RE - 400.0, 0.0, 0.0, 0.0, math.sqrt(MU / (RE + 400.0)), 0.0]
    deb = [-RE - 400.05, 0.0, 0.0, 0.0, math.sqrt(MU / (RE + 400.0)), 0.0]
    warns = detect_conjunctions([sat], [deb], lookahead=3600.0, step_s=60.0)

    assert len(warns) > 0, "Expected at least one conjunction warning"
    assert (
        warns[0].severity == "CRITICAL"
    ), f"Expected CRITICAL for 0.05 km separation, got {warns[0].severity}"
    assert (
        warns[0].current_distance < CRITICAL_DISTANCE
    ), f"Distance {warns[0].current_distance:.4f} km should be < {CRITICAL_DISTANCE} km"


def test_conjunction_detects_advisory():
    """
    Objects separated by 3 km (between WARNING and ADVISORY thresholds)
    must produce an ADVISORY warning. This tier was missing from C++ pre-gamma.
    """
    sat = [-RE - 400.0, 0.0, 0.0, 0.0, math.sqrt(MU / (RE + 400.0)), 0.0]
    deb = [-RE - 400.0 + 3.0, 0.0, 0.0, 0.0, math.sqrt(MU / (RE + 400.0)), 0.001]
    warns = detect_conjunctions([sat], [deb], lookahead=7200.0, step_s=30.0)

    assert len(warns) > 0, "Expected ADVISORY warning for 3 km separation"
    severities = {w.severity for w in warns}
    assert (
        "ADVISORY" in severities or "WARNING" in severities or "CRITICAL" in severities
    ), f"Expected ADVISORY/WARNING/CRITICAL, got {severities}"


def test_conjunction_finds_converging_pairs():
    """
    Two objects starting 100 km apart but moving toward each other must be
    detected. Ensures broad-phase culling doesn't miss pairs that start far
    apart but intersect within lookahead.
    """
    sat = [RE + 400.0, 0.0, 0.0, 0.0, 7.66, 0.0]
    deb = [RE + 400.0 + 100.0, 0.0, 0.0, -0.75, 7.66, 0.0]

    warns = detect_conjunctions([sat], [deb], lookahead=300.0, step_s=1.0)
    assert len(warns) > 0, (
        "Converging pair not detected. Broad-phase may be incorrectly culling "
        "pairs based on t=0 distance alone."
    )


def test_conjunction_tca_accuracy():
    """
    The TCA reported must be within one step_s of the true closest approach.
    Before Brent's method, TCA accuracy was limited to ±step_s.
    """
    sat = [RE + 400.0, 0.0, 0.0, 0.0, 7.66, 0.0]
    deb = [RE + 400.0 + 0.05, 0.0, 0.0, 0.0, 7.66, 0.0001]

    step = 60.0
    warns = detect_conjunctions([sat], [deb], lookahead=3600.0, step_s=step)
    assert len(warns) > 0
    tca = warns[0].time_to_closest_approach
    # TCA should be very early (objects nearly colocated at t=0)
    assert (
        tca < step * 2
    ), f"TCA={tca:.1f}s is too far from expected t≈0. Brent refinement may be broken."


def test_python_conjunction_scans_partial_final_window(monkeypatch):
    """
    The Python detector must scan the partial final interval when lookahead_s is
    not an exact multiple of step_s.
    """
    from astrosis.core import conjunction as conjunction_mod

    def linear_history(states, dt_seconds, steps, **_kwargs):
        history = []
        for step in range(steps + 1):
            t = step * dt_seconds
            rows = []
            for state in states:
                rows.append(
                    [
                        state[0] + state[3] * t,
                        state[1] + state[4] * t,
                        state[2] + state[5] * t,
                        state[3],
                        state[4],
                        state[5],
                    ]
                )
            history.append(rows)
        return np.array(history, dtype=np.float64)

    def linear_batch(states, dt_seconds, steps, **_kwargs):
        t = dt_seconds * steps
        return [
            [
                state[0] + state[3] * t,
                state[1] + state[4] * t,
                state[2] + state[5] * t,
                state[3],
                state[4],
                state[5],
            ]
            for state in states
        ]

    def linear_step(state, dt_seconds, **_kwargs):
        return (
            state[0] + state[3] * dt_seconds,
            state[1] + state[4] * dt_seconds,
            state[2] + state[5] * dt_seconds,
            state[3],
            state[4],
            state[5],
        )

    import astrosis.core.accelerator as accelerator_mod

    monkeypatch.setattr(accelerator_mod, "propagate_batch_full_history", linear_history)
    monkeypatch.setattr(conjunction_mod, "propagate_batch_numpy", linear_batch)
    monkeypatch.setattr(conjunction_mod, "rk4_step", linear_step)

    sat = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    deb = [11.0, 0.0, 0.0, -0.1, 0.0, 0.0]
    warns = conjunction_mod.ConjunctionDetector().detect(
        [sat], [deb], lookahead_s=65.0, step_s=60.0
    )

    assert warns, "Expected advisory warning in the partial final interval"
    assert warns[0].time_to_closest_approach > 60.0


# ─────────────────────────────────────────────────────────────────────────────
# 4. Batch Propagation Equivalence
# ─────────────────────────────────────────────────────────────────────────────


def test_batch_matches_single():
    """
    Batch propagation (C++ or NumPy) must match serial single propagation
    to double precision. Ensures correct batch loop indexing.
    """
    sats = [
        _circular_orbit(400.0),
        _circular_orbit(550.0),
        _circular_orbit(700.0, inclination_deg=51.6),
    ]
    dt, steps = 10.0, 20

    res_batch = propagate_batch(sats, dt, steps)

    for i, state in enumerate(sats):
        curr = tuple(state)
        for _ in range(steps):
            curr = rk4_step(curr, dt)
        for k in range(6):
            assert abs(res_batch[i][k] - curr[k]) < 1e-6, (
                f"Batch sat {i} component {k}: "
                f"batch={res_batch[i][k]:.6f}, single={curr[k]:.6f}"
            )


def test_cpp_incremental_propagation():
    """
    Regression test for incremental propagation correctness.
    Two-step propagation must differ from re-propagating from the initial state,
    ensuring each step uses the previous state's output.
    """
    state = tuple(_circular_orbit(400.0))
    dt = 10.0

    # Correct: incremental propagation
    s1 = rk4_step(state, dt)
    s2 = rk4_step(s1, dt)

    # Incorrect: re-propagating from initial state each time
    incorrect_s1 = rk4_step(state, dt)
    incorrect_s2 = rk4_step(state, dt)

    # s2 should differ from incorrect_s2
    diff = math.sqrt(sum((s2[k] - incorrect_s2[k]) ** 2 for k in range(3)))
    assert diff > 0.001, (
        "Incremental vs re-propagated states are identical. "
        "Propagation may not be using the previous state correctly."
    )


# ─────────────────────────────────────────────────────────────────────────────
# 6. Backend Availability
# ─────────────────────────────────────────────────────────────────────────────


def test_backend_info_returns_dict():
    info = backend_info()
    assert isinstance(info, dict)
    assert 'cuda' in info, f"Missing 'cuda' key: {info}"
    assert 'cpp' in info, f"Missing 'cpp' key: {info}"
    assert 'numpy_batch' in info, f"Missing 'numpy_batch' key: {info}"
    assert 'python' in info, f"Missing 'python' key: {info}"
    assert info['python'] is True, "Python backend must always be available"


def test_propagate_returns_six_elements():
    state = _circular_orbit(400.0)
    result = propagate(state, 10.0)
    assert len(result) == 6
    for v in result:
        assert math.isfinite(v), f"Non-finite value in propagated state: {result}"


def test_mock_gpu_disables_cuda():
    """
    Setting ASTROSIS_MOCK_GPU=1 must force the CUDA backend off.
    Propagation must still succeed via CPU fallback.
    """
    import subprocess

    code = (
        "import os, math\n"
        "os.environ['ASTROSIS_MOCK_GPU'] = '1'\n"
        "from astrosis.core.accelerator import backend_info, propagate\n"
        "from astrosis.constants import MU, RE\n"
        "info = backend_info()\n"
        "assert info['cuda'] is False, f'CUDA should be disabled: {info}'\n"
        "state = [RE + 400.0, 0.0, 0.0, 0.0, math.sqrt(MU / (RE + 400.0)), 0.0]\n"
        "res = propagate(state, 10.0)\n"
        "assert len(res) == 6\n"
        "for v in res:\n"
        "    assert math.isfinite(v)\n"
        "print('Mock GPU: OK')\n"
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=".",
        capture_output=True,
        text=True,
        check=True,
    )
    assert result.stdout.strip() == "Mock GPU: OK", result.stderr


def test_engine_core_import_is_lazy():
    code = (
        "import sys\n"
        "import astrosis.core\n"
        "print('astrosis.core.accelerator' in sys.modules)\n"
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=".",
        capture_output=True,
        text=True,
        check=True,
    )
    assert result.stdout.strip() == "False"


def test_report_passes_converts_teme_initial_state(monkeypatch):
    from astrosis.geo import analysis

    calls = []

    def fake_teme_to_eci(r_teme, v_teme, dt):
        calls.append((r_teme, v_teme, dt))
        return np.array([1.0, 2.0, 3.0]), np.array([0.1, 0.2, 0.3])

    class FakeSatrec:
        @classmethod
        def twoline2rv(cls, _line1, _line2):
            return cls()

        def sgp4(self, _jd, _jdfrac):
            return 0, [7000.0, 0.0, 0.0], [0.0, 7.5, 0.0]

    fake_sgp4 = types.ModuleType("sgp4")
    fake_api = types.ModuleType("sgp4.api")
    fake_api.Satrec = FakeSatrec
    fake_api.jday = lambda *_args: (2451545.0, 0.0)

    class FakeIngestor:
        def get_satellites(self, **_kwargs):
            return [
                {
                    "satellite_name": "TESTSAT",
                    "line1": "1 00000U 00000A   25001.00000000  .00000000  00000+0  00000+0 0  0000",
                    "line2": "2 00000   0.0000   0.0000 0000000   0.0000   0.0000  1.00000000    00",
                }
            ]

    monkeypatch.setitem(sys.modules, "sgp4", fake_sgp4)
    monkeypatch.setitem(sys.modules, "sgp4.api", fake_api)
    monkeypatch.setattr(analysis, "teme_to_eci", fake_teme_to_eci)

    result = analysis.report_passes(
        0,
        0.0,
        0.0,
        0.0,
        start_dt=__import__("datetime").datetime(2025, 1, 1),
        hours=0.0,
        ingestor=FakeIngestor(),
    )

    assert result["satellite"] == "TESTSAT"
    assert len(calls) == 1


# ─────────────────────────────────────────────────────────────────────────────
# 7. Physics: circular orbit stays circular
# ─────────────────────────────────────────────────────────────────────────────


def test_circular_orbit_eccentricity():
    """
    A circular orbit should maintain near-zero eccentricity over 10 orbits.
    Eccentricity drift indicates energy non-conservation in the integrator.
    """
    state = tuple(_circular_orbit(500.0))
    T = 2 * math.pi * math.sqrt((RE + 500.0) ** 3 / MU)
    dt = 30.0
    steps = int(10 * T / dt)

    def eccentricity(s):
        r = math.sqrt(sum(x * x for x in s[:3]))
        h_vec = (
            s[1] * s[5] - s[2] * s[4],
            s[2] * s[3] - s[0] * s[5],
            s[0] * s[4] - s[1] * s[3],
        )
        hx, hy, hz = h_vec
        vxh = (s[4] * hz - s[5] * hy, s[5] * hx - s[3] * hz, s[3] * hy - s[4] * hx)
        e_vec = (vxh[0] / MU - s[0] / r, vxh[1] / MU - s[1] / r, vxh[2] / MU - s[2] / r)
        return math.sqrt(e_vec[0] ** 2 + e_vec[1] ** 2 + e_vec[2] ** 2)

    e0 = eccentricity(state)
    curr = state
    max_e = e0
    for i in range(steps):
        curr = rk4_step(curr, dt)
        if i % 100 == 0:
            max_e = max(max_e, eccentricity(curr))

    assert max_e < 0.01, (
        f"Eccentricity grew from {e0:.2e} to {max_e:.2e} over 10 orbits. "
        "Circular orbit is not stable under J2."
    )


# ─────────────────────────────────────────────────────────────────────────────
# 8. Physics: two-body analytic vs RK4
# ─────────────────────────────────────────────────────────────────────────────


def test_two_body_analytic_match():
    """
    RK4 (with J2 always active) should conserve orbital energy to high precision
    over one orbit. For a circular equatorial orbit, J2 causes RAAN precession
    but does NOT change the radial distance. Check that r stays constant.
    """
    from astrosis.constants import MU

    r0 = RE + 400.0
    v0 = math.sqrt(MU / r0)
    T = 2 * math.pi * math.sqrt(r0**3 / MU)
    dt = 60.0
    steps = int(T / dt)

    state = (r0, 0.0, 0.0, 0.0, v0, 0.0)
    curr = tuple(state)
    for _ in range(steps):
        curr = rk4_step(curr, dt, mjd0=0.0)

    rf = math.sqrt(curr[0] ** 2 + curr[1] ** 2 + curr[2] ** 2)
    rel_err = abs(rf - r0) / r0
    assert rel_err < 1e-6, (
        f"Radial distance changed by {rel_err:.2e} after 1 orbit. "
        "Energy is not conserved in two-body propagation."
    )
