import httpx
from datetime import datetime, timedelta
from typing import List, Optional
import logging
import os
import pathlib
from importlib.resources import files as _pkg_files

logger = logging.getLogger(__name__)

LOCAL_CACHE_DIR = str(pathlib.Path.home() / ".cache" / "astrosis" / "tle")
BUNDLED_CACHE = str(_pkg_files("astrosis.data").joinpath("active.txt"))
CELESTRAK_API_URL = "https://celestrak.org/NORAD/elements/gp.php"
SPACETRACK_LOGIN_URL = "https://www.space-track.org/ajaxauth/login"
SPACETRACK_TLE_URL = (
    "https://www.space-track.org/basicspaceradar/query"
    "/class/tle_latest/ORDINAL/NORAD_CAT_ID/EPOCH/now/format/tle"
)
# TODO: update this after 2056 lol
EPOCH_YEAR_CUTOFF = 57


class TLEIngestor:
    def __init__(self, cache_dir: str = LOCAL_CACHE_DIR):
        self.api_url = CELESTRAK_API_URL
        self.cache_dir = cache_dir
        os.makedirs(self.cache_dir, exist_ok=True)

    def _get_cache_path(self, satellite_id: Optional[str] = None) -> str:
        if satellite_id:
            return os.path.join(self.cache_dir, f"{satellite_id}.txt")
        return os.path.join(self.cache_dir, "active.txt")

    def _is_cache_valid(self, cache_path: str, max_age_hours: int = 24) -> bool:
        if not os.path.exists(cache_path):
            return False
        mtime = os.path.getmtime(cache_path)
        age = datetime.now() - datetime.fromtimestamp(mtime)
        return age <= timedelta(hours=max_age_hours)

    def _try_fetch(
        self, url: str, params: dict, timeout: float = 15.0
    ) -> Optional[str]:
        try:
            with httpx.Client(timeout=timeout) as client:
                resp = client.get(url, params=params)
                resp.raise_for_status()
                return resp.text.strip()
        except (httpx.HTTPStatusError, httpx.TimeoutException, httpx.ConnectError) as e:
            logger.warning("TLE fetch failed from %s: %s", url, e)
            return None

    def _try_spacetrack(self) -> Optional[str]:
        user = os.environ.get("SPACETRACK_USER")
        pwd = os.environ.get("SPACETRACK_PASS")
        if not user or not pwd:
            return None
        try:
            with httpx.Client(timeout=10.0) as client:
                login = client.post(
                    SPACETRACK_LOGIN_URL, data={"identity": user, "password": pwd}
                )
                if login.status_code != 200:
                    return None
                resp = client.get(SPACETRACK_TLE_URL)
                if resp.status_code == 200:
                    return resp.text.strip()
        except (httpx.HTTPStatusError, httpx.TimeoutException, httpx.ConnectError) as e:
            logger.warning("Space-Track fetch failed: %s", e)
        return None

    def fetch_tle_data(
        self, satellite_id: Optional[str] = None, force_refresh: bool = False
    ) -> List[str]:
        # CelesTrak -> Space-Track -> stale cache -> bundled active.txt
        cache_path = self._get_cache_path(satellite_id)
        if not force_refresh and self._is_cache_valid(cache_path):
            logger.info("Loading TLEs from cache: %s", cache_path)
            with open(cache_path, "r", encoding="utf-8") as f:
                return f.read().strip().splitlines()

        params = {"FORMAT": "TLE"}
        if satellite_id:
            params["CATNR"] = satellite_id
        else:
            params["GROUP"] = "active"

        text = self._try_fetch(self.api_url, params, timeout=15.0)
        if text:
            with open(cache_path, "w", encoding="utf-8") as f:
                f.write(text)
            return text.splitlines()

        text = self._try_spacetrack()
        if text:
            with open(cache_path, "w", encoding="utf-8") as f:
                f.write(text)
            return text.splitlines()

        if os.path.exists(cache_path):
            logger.warning("All remote TLE fetches failed, using stale cache.")
            with open(cache_path, "r", encoding="utf-8") as f:
                return f.read().strip().splitlines()

        if os.path.exists(BUNDLED_CACHE):
            logger.warning("Using bundled fallback TLE cache from data/active.txt")
            with open(BUNDLED_CACHE, "r", encoding="utf-8") as f:
                text = f.read().strip()
            with open(cache_path, "w", encoding="utf-8") as f:
                f.write(text)
            return text.splitlines()

        return []

    @staticmethod
    def _tle_checksum_valid(line: str) -> bool:
        if len(line) < 69:
            return False
        checksum = 0
        for ch in line[:68]:
            if ch.isdigit():
                checksum += int(ch)
            elif ch == "-":
                checksum += 1
        return checksum % 10 == int(line[68])

    def parse_tle_lines(self, lines: List[str]) -> List[dict]:
        tle_entries = []
        i = 0
        while i < len(lines):
            if i + 2 < len(lines):
                name = lines[i].strip()
                line1 = lines[i + 1].strip()
                line2 = lines[i + 2].strip()

                if not (
                    self._tle_checksum_valid(line1) and self._tle_checksum_valid(line2)
                ):
                    logger.warning(f"Skipping TLE '{name}': invalid checksum")
                    i += 3
                    continue

                if not (line1.startswith("1 ") and line2.startswith("2 ")):
                    logger.warning(f"Skipping TLE block at {i}: bad line markers")
                    i += 1
                    continue

                norad_id = int(line1[2:7]) if len(line1) > 6 else None

                epoch = None
                if len(line1) > 32:
                    year_str = line1[18:20]
                    day_str = line1[20:32]
                    year = (
                        2000 + int(year_str)
                        if int(year_str) < EPOCH_YEAR_CUTOFF
                        else 1900 + int(year_str)
                    )
                    day_of_year = float(day_str)
                    epoch = datetime(year, 1, 1) + timedelta(days=day_of_year - 1)

                tle_entries.append(
                    {
                        "norad_id": norad_id,
                        "satellite_name": name,
                        "line1": line1,
                        "line2": line2,
                        "epoch": epoch,
                    }
                )
                i += 3
            else:
                i += 1

        return tle_entries

    def get_satellites(
        self, satellite_id: Optional[str] = None, force_refresh: bool = False
    ) -> List[dict]:
        lines = self.fetch_tle_data(satellite_id, force_refresh)
        return self.parse_tle_lines(lines)


tle_ingestor = TLEIngestor()
